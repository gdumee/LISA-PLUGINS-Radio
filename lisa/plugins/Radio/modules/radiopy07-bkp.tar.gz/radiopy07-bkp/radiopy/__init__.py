###########################################################################
 #   Copyright (C) 2007-2014 by Guy Rutenberg                              #
 #   guyrutenberg@gmail.com                                                #
 #                                                                         #
 #   This program is free software; you can redistribute it and/or modify  #
 #   it under the terms of the GNU General Public License as published by  #
 #   the Free Software Foundation; either version 2 of the License, or     #
 #   (at your option) any later version.                                   #
 #                                                                         #
 #   This program is distributed in the hope that it will be useful,       #
 #   but WITHOUT ANY WARRANTY; without even the implied warranty of        #
 #   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         #
 #   GNU General Public License for more details.                          #
 #                                                                         #
 #   You should have received a copy of the GNU General Public License     #
 #   along with this program; if not, write to the                         #
 #   Free Software Foundation, Inc.,                                       #
 #   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             #
############################################################################

import sys
import os
import subprocess

import time
import ConfigParser
import tempfile
import random
import threading
from stations_local import StationsLocal
from stations_tunein import StationsTunein

import logging
import signal


class StationResolver():
    handlers = [StationsLocal(), StationsTunein()]

    @staticmethod
    def get_station(name):
        logging.debug("StationResolver: Searching for: {}".format(name))
        for h in StationResolver.handlers:
            station = h.get_station(name)
            if station is not None:
                return station
        logging.info('StationResolver: no station found')

 

class Player:
    """
    The radiopy player
    """
    def __init__(self, options={}):
        pass

    def play(self, station_name, wake=0, sleep=0, cache=320, record=""):
        """
        station_name - The name of the station to play.
        wake - Number of minutes to wait before starting to play.
        sleep - Number of minutes to play radio before killing it.
        cache - The cache size ink kbits.
        record - A file name to record stream to.
        """
        #loock for station
        station = StationResolver.get_station(station_name)
        #if not station:
        logging.debug ('Player.Play station : {}'.format(station))
        if station == None : return 'no-station'
        if 'name' in station :
            if station['name'].lower() <> station_name.lower():
                print "radiopy couldn't find the requested station \"%s\"" % station_name
                print "Try --list to see the available stations list"
                return 'no-station' 
        
        
        #arguments list
        execargs =['mplayer', '-softvol','-vo','null',]
        #execargs += ['-v',]   #-v verbose
        if wake > 0:
            print "radiopy will wake up in {} minutes".format(wake)
            time.sleep(60*wake)

        if cache < 32: #mplayer requires cache>=32
            cache = 32
        execargs += ['-cache', str(cache)]

        if station.has_key("stream_id"):
            execargs += ['-aid', str(station["stream_id"])]

        if station.get("playlist", False) == "yes":
            execargs.append('-playlist')

        execargs.append(station['stream'])
        #http://www.mplayerhq.hu/DOCS/man/en/mplayer.1.html
        
        #launch
        pid = None
        if record:
            record_args = ['-dumpstream', '-dumpfile', record]
            execargs += record_args
        if sleep:
            print "radiopy will go to sleep in %d minutes" % sleep
            if not pid:
                proc = subprocess.Popen(execargs)
            def kill_mplayer():
                proc.terminate()
            threading.Timer(60*sleep, kill_mplayer).start()
        else:
            #normal case in Neo
            logging.debug('Player.Play: arg {},, {}.'.format(execargs[0],execargs))
            
            #start subprocess
            #stop after a couple of seconds
            #get its ouput and check if it started "Starting playback..."
            #if no : error
            #if yes : launch it again in a separate thread to get return into Neo easly
            #return child thread PID 
            
            """
            try :
                def cbk(signum, frame):  #callback function for watchdog
                    #print signum
                    #print frame
                    logging.error('Player.play PID error :{}'.format(proc2.pid))
                    #os.kill(proc2.pid, signal.CTRL_BREAK_EVENT)
                    os.kill(proc2.pid, 'why dont you want to die MTF ?')
                    proc2.kill()
                    raise TypeError
                
                #self.proc = subprocess.check_output(args)
                signal.signal(signal.SIGALRM,cbk)
                signal.alarm(6) # watchdog if mplayer bugs
                execargs2=list(execargs) 
                execargs2 +='-volume','0'  #mute
                proc2 = subprocess.Popen(execargs2, stdout=subprocess.PIPE)
                time.sleep(3) #wait for mplayer
                proc2.terminate()
                
                ret = proc2.communicate()[0]
                signal.alarm(0)
            except :
                pass
            """
            execargs2=list(execargs) 
            execargs2 +='-volume','0'  #mute
            proc2 = subprocess.Popen(execargs2, stdout=subprocess.PIPE)
            time.sleep(1) #wait for mplayer to check if station exist
            proc2.terminate()
            #ret =''
            #ret = proc2.communicate()[0]
            
            #print '**********************',ret
            if "Starting playback..." in proc2.communicate()[0]:
                logging.info('mplayer starts playing')
                proc3 = subprocess.Popen(execargs)  #new process without capture
                print 'pid',proc3.pid
                #print 'inst',proc3.terminate()
                return 'cest parti'

            print 'dont start1'
        return 'dont start2'  #not normal



    def play_random(self, *args, **kwds):
        """
        Plays a random station.
        """
        self.station_list = StationsLocal()
        station_name = random.choice(self.station_list._stations.keys())  #random sur le fichier radiopy.default
        print "Playing {}".format(station_name)
        sys.stdout.flush() # before out output gets mangled in mplayer's output
        self.play(station_name, *args, **kwds)


    def print_list(self):
        """
        Prints the station list.
        """
        self.station_list = StationsLocal()
        maxname = max(self.station_list, key=lambda x: len(x[0]))
        maxlen = len(maxname)
        for name,station in self.station_list:
            print name.ljust(maxlen+1), station.get("home","")

        print "Total:", len(self.station_list), "recognized stations"

# vim: ai ts=4 sts=4 et sw=4
